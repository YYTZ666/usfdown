Copyright © 2023 EarthDLL. All rights reserved.

如果翻译结果有任何争议，以中文版本为准
If there is any dispute about the translation results, the Chinese version shall prevail

欢迎使用本插件
本插件是基于《Minecraft基岩版》官方提供的gametest框架制作的
适用于个人存档与bds为核心的服务器
插件地址：https://www.minebbs.com/resources/usf.5475/

Welcome to use this plugin.
This plugin is based on the gametest framework officially provided by Minecraft Bedrock Edition
It suitable for personal archiving and bds based servers
Plugin address:
https://www.minebbs.com/resources/usf.5475/


插件作者：EarthDLL
b站@ED的周记本(UID:85607592)
苦力怕论坛@EarthDLL
MineBBS@地球DLL
插件管理员：
1.b站@悠米看悠米(UID:46506172)
2.b站@mcqcbby(UID:1811117435)

Plugin author: EarthDLL
bilibili @EarthDLL (UID: 85607592)
KLP Forum(klpbbs.com)@EarthDLL
MineBBS(minebbs.com) @地球DLL
Plugin admin:
1.bilibili@悠米看悠米(UID: 46506172)
2.bilibili@mcqcbby (UID: 1811117435)

————————————

目前官方发布/授权发布的资源地址:
1.https://www.minebbs.com/threads/usf.17109/
2.https://klpbbs.com/thread-92297-1-1.html

Official/Authorized resource address:
1. https://www.minebbs.com/threads/usf.17109/
2. https://klpbbs.com/thread-92297-1-1.html

————————————

使用方法：
1.新建存档/打开存档设置
2.开启实验性玩法-测试版API
3.加载插件行为包、资源包
4.进入存档，在主世界运行命令/tickingarea add 0 0 0 0 0 0
5.运行命令/tag 玩家名称 add "op,玩家名称" 或 /tag @s add "op,你的游戏名" 获取插件op

Usage method:
1. New Archive/Open Archive Settings
2. Enable experimental gameplay - beta API
3. Load plugin behavior pack and resource pack
4. Enter the archive and run the command
    /tickingarea add 0 0 0 0 0 0 0 (in the overworld)
5. Run the command /tag player_name add "op,player_name" or /tag @s add "op,your_game_name" to obtain the plugin op


————————————
本页面需要完善

