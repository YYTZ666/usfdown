Copyright © 2023 EarthDLL. All rights reserved.

欢迎使用本插件
本插件是基于《Minecraft基岩版》官方提供的gametest框架制作的
适用于个人存档与bds为核心的服务器
插件地址：https://www.minebbs.com/resources/usf.5475/

插件作者：EarthDLL
b站@EarthDLL(UID:85607592)
苦力怕论坛@EarthDLL
MineBBS@EarthDLL

插件管理员：
1.b站@悠米看悠米(UID:46506172)
2.b站@mcqcbby(UID:1811117435)

————————————
版权说明
1.该插件已由开源转向闭源，在插件0.3.2及以上版本的代码不得私自更改。
2.你可以免费转发，但必须提供原作者。
3.使用改插件的用户不得私自使用反混淆、反加密等手段获取源代码，并且进行修改。
4.严禁付费转发本插件，严禁私改原作者，后果自负。
5.请勿套用本插件的代码，一切套用视为盗用源代码

目前官方发布/授权发布的资源地址:
1.https://www.minebbs.com/threads/usf.17109/
2.https://klpbbs.com/thread-92297-1-1.html
————————————

使用方法：
1.新建存档/打开存档设置
2.开启实验性玩法-测试版API
3.加载插件行为包、资源包
4.进入存档，在主世界运行命令/tickingarea add 0 0 0 0 0 0
5.运行命令/tag 玩家名称 "op,玩家名称" 或 /tag @s "op,你的游戏名" 获取插件op

————————————
本页面需要完善